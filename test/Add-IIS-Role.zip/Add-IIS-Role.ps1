Configuration Main
{

Param 
	(
		[ValidateNotNullorEmpty()]
		[string]$nodeName,

		[ValidateNotNullorEmpty()]
		[string]$DomainName,

		[Parameter(Mandatory = $true)]
    [ValidateNotNullorEmpty()]
    [System.Management.Automation.PSCredential]
    $DomainCredentials

	)


Import-DscResource -ModuleName PSDesiredStateConfiguration, xComputerManagement
$AuthenticationCredentials = $DomainCredentials

Node $nodeName
  {
	WindowsFeature IIS
	{
		Ensure = "Present"
		Name = "Web-Server"
		IncludeAllSubFeature = $true
	}
	WindowsFeature BitLocker
	{
		Ensure = "Present"
		Name = "BitLocker"
	}

	WindowsFeature EnhancedStorage
	{
		Ensure = "Present"
		Name = "EnhancedStorage"
	}

	WindowsFeature FileAndStorage-Services
	{
		Ensure = "Present"
		Name = "FileAndStorage-Services"
	}
	WindowsFeature NET-Framework-45-Core
	{
		Ensure = "Present"
		Name = "NET-Framework-45-Core"
	}
	  	WindowsFeature NET-Framework-45-Features
	{
		Ensure = "Present"
		Name = "NET-Framework-45-Features"
	}
	  	WindowsFeature NET-WCF-Services45
	{
		Ensure = "Present"
		Name = "NET-WCF-Services45"
	}
	  	WindowsFeature NET-WCF-TCP-PortSharing45
	{
		Ensure = "Present"
		Name = "NET-WCF-TCP-PortSharing45"
	}
	  	WindowsFeature PwSh
	{
		Ensure = "Present"
		Name = "PowerShell"
	}
	  	WindowsFeature PwSh-ISE
	{
		Ensure = "Present"
		Name = "PowerShell-ISE"
	}
	  	WindowsFeature PwShRoot
	{
		Ensure = "Present"
		Name = "PowerShellRoot"
	}
	  	WindowsFeature Storage-Services
	{
		Ensure = "Present"
		Name = "Storage-Services"
	}
	  	WindowsFeature Web-Common-Http
	{
		Ensure = "Present"
		Name = "Web-Common-Http"
	}
	  	WindowsFeature Web-Default-Doc
	{
		Ensure = "Present"
		Name = "Web-Default-Doc"
	}
	  	WindowsFeature Web-Dir-Browsing
	{
		Ensure = "Present"
		Name = "Web-Dir-Browsing"
	}
	  	WindowsFeature Web-Filtering
	{
		Ensure = "Present"
		Name = "Web-Filtering"
	}
	  	WindowsFeature Web-Health
	{
		Ensure = "Present"
		Name = "Web-Health"
	}
	  	WindowsFeature Web-Http-Errors
	{
		Ensure = "Present"
		Name = "Web-Http-Errors"
	}
	WindowsFeature Web-Http-Logging
	{
		Ensure = "Present"
		Name = "Web-Http-Logging"
	}
	WindowsFeature Web-Mgmt-Console
	{
		Ensure = "Present"
		Name = "Web-Mgmt-Console"
	}
	WindowsFeature Web-Mgmt-Tools
	{
		Ensure = "Present"
		Name = "Web-Mgmt-Tools"
	}
	WindowsFeature Web-Performance
	{
		Ensure = "Present"
		Name = "Web-Performance"
	}
	WindowsFeature Web-Security
	{
		Ensure = "Present"
		Name = "Web-Security"
	}
	WindowsFeature Web-Server
	{
		Ensure = "Present"
		Name = "Web-Server"
	}
	WindowsFeature Web-Stat-Compression
	{
		Ensure = "Present"
		Name = "Web-Stat-Compression"
	}
	WindowsFeature Web-Static-Content
	{
		Ensure = "Present"
		Name = "Web-Static-Content"
	}
	WindowsFeature Web-WebServer
	{
		Ensure = "Present"
		Name = "Web-WebServer"
	}
	WindowsFeature Windows-Defender
	{
		Ensure = "Present"
		Name = "Windows-Defender"
	}
	WindowsFeature Windows-Defender-Features
	{
		Ensure = "Present"
		Name = "Windows-Defender-Features"
	}
	WindowsFeature Windows-Defender-Gui
	{
		Ensure = "Present"
		Name = "Windows-Defender-Gui"
	}
	WindowsFeature WoW64-Support
	{
		Ensure = "Present"
		Name = "WoW64-Support"
	}
  }
	xComputer JoinDomain
	{
		Name       = $nodeName
        DomainName = $DomainName
        Credential = $AuthenticationCredentials # Credential to join to domain
	}
}