Configuration Example
{
    param
    (
        [Parameter()]
        [System.String[]]
        $NodeName,

        [Parameter()]
        [System.String[]]
        $DomainName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullorEmpty()]
        [System.Management.Automation.PSCredential]
        $Credential
    )

    Import-DscResource -Module ComputerManagementDsc

    Node $NodeName
    {
        Computer JoinDomain
        {
            Name       = $NodeName
            DomainName = $DomainName
            Credential = $Credential # Credential to join to domain
        }
    }
}